USER MANUAL - CRYPTOWOLF.PY

This program allows you to predict the ClosePrice of a 12-h candle (Exchange: Bitstamp, Crypto Coin: Bitcoin FIAT Coin: USD Dollar).

In the specific, the program has two features:

1.PREDICT DAILY 12-H OPENED CANDLE: At the start of the program, it tries to download the last 12-h opened candle and if operation go to successful, it prints the predicted price.

2.PREDICT FROM USER INPUT: After the daily candle prediction, program shows a menu to the user, this menu allows user to predict a 12-h candle inserted from him or exit from the program.
